/* =====================================================
   PORTFOLIO JAVASCRIPT - RAVITA CAHYANINGSIH
===================================================== */

document.addEventListener("DOMContentLoaded", () => {

    /* =================================================
       1. TYPING EFFECT
    ================================================= */

    const typingText = document.getElementById("typing-text");

    if (typingText) {

        const texts = [
            "Pelajar RPL",
            "Web Developer Pemula",
            "Suka Coding 💻",
            "Creative Learner ✨"
        ];

        let textIndex = 0;
        let charIndex = 0;
        let deleting = false;

        function typeEffect() {

            const currentText = texts[textIndex];

            if (!deleting) {

                typingText.textContent =
                    currentText.substring(0, charIndex + 1);

                charIndex++;

                if (charIndex === currentText.length) {

                    deleting = true;

                    setTimeout(typeEffect, 1500);
                    return;
                }

            } else {

                typingText.textContent =
                    currentText.substring(0, charIndex - 1);

                charIndex--;

                if (charIndex === 0) {

                    deleting = false;

                    textIndex++;

                    if (textIndex >= texts.length) {
                        textIndex = 0;
                    }
                }
            }

            setTimeout(
                typeEffect,
                deleting ? 50 : 100
            );
        }

        typeEffect();
    }


    /* =================================================
       2. NAVBAR BERUBAH SAAT SCROLL
    ================================================= */

    const header = document.querySelector("header");

    function navbarScroll() {

        if (window.scrollY > 50) {
            header.classList.add("scrolled");
        } else {
            header.classList.remove("scrolled");
        }
    }

    window.addEventListener("scroll", navbarScroll);

    navbarScroll();


    /* =================================================
       3. NAVBAR ACTIVE
    ================================================= */

    const navLinks = document.querySelectorAll(".nav-menu a");
    const sections = document.querySelectorAll("section[id]");

    function updateActiveNav() {

        let currentSection = "";

        sections.forEach(section => {

            const sectionTop = section.offsetTop - 180;
            const sectionHeight = section.offsetHeight;

            if (
                window.scrollY >= sectionTop &&
                window.scrollY < sectionTop + sectionHeight
            ) {
                currentSection = section.getAttribute("id");
            }

        });

        navLinks.forEach(link => {

            link.classList.remove("active");

            if (
                link.getAttribute("href") ===
                "#" + currentSection
            ) {
                link.classList.add("active");
            }

        });
    }

    window.addEventListener("scroll", updateActiveNav);

    updateActiveNav();


    /* =================================================
       4. SCROLL REVEAL
    ================================================= */

    const revealElements = document.querySelectorAll(
        ".section-title, " +
        ".about-container, " +
        ".strength-card, " +
        ".timeline-item, " +
        ".organization-card, " +
        ".skill, " +
        ".achievement-card, " +
        ".portfolio-card, " +
        ".gallery-item, " +
        ".stat-box"
    );

    revealElements.forEach(element => {
        element.classList.add("scroll-hidden");
    });


    const revealObserver = new IntersectionObserver(
        entries => {

            entries.forEach(entry => {

                if (entry.isIntersecting) {

                    entry.target.classList.add("scroll-show");

                    revealObserver.unobserve(
                        entry.target
                    );
                }

            });

        },
        {
            threshold: 0.15
        }
    );


    revealElements.forEach(element => {
        revealObserver.observe(element);
    });


    /* =================================================
       5. CARD MUNCUL BERTAHAP
    ================================================= */

    const cardGroups = [
        ".strength-card",
        ".portfolio-card",
        ".gallery-item",
        ".stat-box",
        ".skill"
    ];

    cardGroups.forEach(selector => {

        const cards = document.querySelectorAll(selector);

        cards.forEach((card, index) => {

            card.style.transitionDelay =
                `${index * 0.12}s`;

        });

    });


    /* =================================================
       6. LIGHTBOX FOTO
    ================================================= */

    const galleryImages =
        document.querySelectorAll(
            ".gallery-item img"
        );

    if (galleryImages.length > 0) {

        const lightbox = document.createElement("div");

        lightbox.className = "lightbox";

        lightbox.innerHTML = `
            <div class="lightbox-content">

                <button class="lightbox-close">
                    ×
                </button>

                <img src="" alt="Preview">

                <div class="lightbox-caption"></div>

            </div>
        `;

        document.body.appendChild(lightbox);


        const lightboxImage =
            lightbox.querySelector(
                ".lightbox-content img"
            );

        const lightboxCaption =
            lightbox.querySelector(
                ".lightbox-caption"
            );

        const closeButton =
            lightbox.querySelector(
                ".lightbox-close"
            );


        galleryImages.forEach(image => {

            image.style.cursor = "pointer";

            image.addEventListener("click", () => {

                lightboxImage.src = image.src;

                lightboxCaption.textContent =
                    image.alt || "Galeri Foto";

                lightbox.classList.add("active");

                document.body.style.overflow =
                    "hidden";
            });

        });


        function closeLightbox() {

            lightbox.classList.remove("active");

            document.body.style.overflow = "";
        }


        closeButton.addEventListener(
            "click",
            closeLightbox
        );


        lightbox.addEventListener(
            "click",
            event => {

                if (event.target === lightbox) {
                    closeLightbox();
                }

            }
        );


        document.addEventListener(
            "keydown",
            event => {

                if (
                    event.key === "Escape" &&
                    lightbox.classList.contains("active")
                ) {
                    closeLightbox();
                }

            }
        );
    }


    /* =================================================
       7. BACK TO TOP
    ================================================= */

    const backTop = document.createElement("button");

    backTop.className = "back-top";

    backTop.innerHTML = "↑";

    backTop.setAttribute(
        "aria-label",
        "Kembali ke atas"
    );

    document.body.appendChild(backTop);


    function backTopScroll() {

        if (window.scrollY > 500) {

            backTop.classList.add("show");

        } else {

            backTop.classList.remove("show");

        }

    }

    window.addEventListener(
        "scroll",
        backTopScroll
    );


    backTop.addEventListener(
        "click",
        () => {

            window.scrollTo({
                top: 0,
                behavior: "smooth"
            });

        }
    );


    /* =================================================
       8. CURSOR GLOW
    ================================================= */

    const cursorGlow =
        document.createElement("div");

    cursorGlow.className = "cursor-glow";

    document.body.appendChild(cursorGlow);


    document.addEventListener(
        "mousemove",
        event => {

            cursorGlow.style.left =
                event.clientX + "px";

            cursorGlow.style.top =
                event.clientY + "px";

        }
    );


    /* =================================================
       9. PARALLAX EFFECT
    ================================================= */

    const heroPhoto =
        document.querySelector(".hero-photo");

    if (heroPhoto) {

        window.addEventListener(
            "scroll",
            () => {

                if (window.innerWidth > 600) {

                    const scroll =
                        window.scrollY;

                    heroPhoto.style.transform =
                        `translateY(${scroll * 0.12}px)`;

                }

            }
        );
    }


    /* =================================================
       10. RIPPLE BUTTON
    ================================================= */

    const buttons =
        document.querySelectorAll(
            ".btn-primary, .btn-secondary"
        );


    buttons.forEach(button => {

        button.addEventListener(
            "click",
            function(event) {

                const ripple =
                    document.createElement("span");

                ripple.classList.add("ripple");

                const rect =
                    this.getBoundingClientRect();

                const x =
                    event.clientX - rect.left;

                const y =
                    event.clientY - rect.top;


                ripple.style.left =
                    x + "px";

                ripple.style.top =
                    y + "px";


                this.appendChild(ripple);


                setTimeout(() => {

                    ripple.remove();

                }, 600);

            }
        );

    });


    /* =================================================
       11. SKILL BAR ANIMATION
    ================================================= */

    const skills =
        document.querySelectorAll(
            ".skill-progress"
        );


    skills.forEach(skill => {

        const finalWidth =
            getComputedStyle(skill).width;

    
    });


    const skillObserver =
        new IntersectionObserver(
            entries => {

                entries.forEach(entry => {

                    if (entry.isIntersecting) {

                        const skill =
                            entry.target;

                        skill.style.transition =
                            "width 1.8s ease";

                        skill.style.width =
                            skill.dataset.width;

                        skillObserver.unobserve(
                            skill
                        );

                    }

                });

            },
            {
                threshold: 0.5
            }
        );


    skills.forEach(skill => {

        skillObserver.observe(skill);

    });


    /* =================================================
       12. HOVER EFFECT PORTFOLIO
    ================================================= */

    const portfolioCards =
        document.querySelectorAll(
            ".portfolio-card"
        );


    portfolioCards.forEach(card => {

        card.addEventListener(
            "mousemove",
            event => {

                const rect =
                    card.getBoundingClientRect();

                const x =
                    event.clientX - rect.left;

                const y =
                    event.clientY - rect.top;

                const centerX =
                    rect.width / 2;

                const centerY =
                    rect.height / 2;

                const rotateX =
                    (y - centerY) / 20;

                const rotateY =
                    (centerX - x) / 20;


                card.style.transform =
                    `perspective(800px)
                     rotateX(${rotateX}deg)
                     rotateY(${rotateY}deg)
                     translateY(-5px)`;
            }
        );


        card.addEventListener(
            "mouseleave",
            () => {

                card.style.transform = "";

            }
        );

    });


    /* =================================================
       13. SMOOTH NAVIGATION
    ================================================= */

    navLinks.forEach(link => {

        link.addEventListener(
            "click",
            event => {

                const targetId =
                    link.getAttribute("href");

                const target =
                    document.querySelector(
                        targetId
                    );


                if (target) {

                    event.preventDefault();

                    const headerHeight =
                        header.offsetHeight + 20;

                    const targetPosition =
                        target.offsetTop -
                        headerHeight;


                    window.scrollTo({

                        top: targetPosition,

                        behavior: "smooth"

                    });

                }

            }
        );

    });


    /* =================================================
       14. ORGANIZATION / ACHIEVEMENT HOVER
    ================================================= */

    const specialCards =
        document.querySelectorAll(
            ".organization-card, " +
            ".achievement-card, " +
            ".timeline-card"
        );


    specialCards.forEach(card => {

        card.addEventListener(
            "mouseenter",
            () => {

                card.style.transform =
                    "translateY(-5px)";

                card.style.transition =
                    "0.3s ease";

            }
        );


        card.addEventListener(
            "mouseleave",
            () => {

                card.style.transform = "";

            }
        );

    });


    console.log(
        "✨ Portfolio Ravita berhasil dijalankan!"
    );

});